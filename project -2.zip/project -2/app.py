from flask import Flask, Blueprint
from flask_restx import Api
from cars import api as cars_api
from mechanic import api as mechanics_api

def create_app():
    url_prefix = ""
    app = Flask(__name__)
    app.url_map.strict_slashes = False
    blueprint = Blueprint("api", __name__, url_prefix=url_prefix)
    api = Api(
        title="GIve some title here",
        version="1.0",
        description="hescription here"
    )
    api.add_namespace(ns=cars_api, path="/cars")
    api.add_namespace(ns=mechanics_api, path="/mechanics")
    api.init_app(blueprint)
    app.register_blueprint(blueprint)
    return app

app = create_app()
if __name__=="__main__":
    app.run(debug=True)