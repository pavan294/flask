from flask import Flask, Blueprint
from flask_restx import Api, Resource, fields

api_v1 = Blueprint("api", __name__, url_prefix="/cars")

api = Api(api_v1, version="1.0", title="car API", description="A simple car API",)

ns = api.namespace("cars", description="car operations")
import json

todo = api.model('Model', {
    'name': fields.String,
    'color': fields.String,
    'cost': fields.Integer,
})
parser = api.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "color", type=str, required=True
)
parser.add_argument(
    "cost", type=int, required=True,
)
car_patch = api.parser()
car_patch.add_argument(
    'color',type=str
    )
car_patch.add_argument(
    'name',type=str
    )
car_patch.add_argument(
    'cost',type=int
    )
def abort_if_todo_exist(todo_id):
    """[check whether mechanic is assigned]

    Args:
        todo_id ([type]): [int]
    """
    with open('data/mechanics.json','r') as f:
            data = f.read()
            records = json.loads(data)
            for r in records:
                for k,v in r.items():
                    if v['car_id'] ==todo_id:
                       return True
@ns.route("/filter/<string:todo_id>")
class Workers(Resource):
    def get(self,todo_id):
       with open('data/mechanics.json','r') as f:
            data = f.read()
            records = json.loads(data)
            l=[]
            for r in records:
                for k,v in r.items():
                    if v['car_id'] ==todo_id:
                       l.append(r)
            return l
      
@ns.route("/<string:todo_id>")
class Todo(Resource):
    """Show a single todo item and lets you delete them"""

    
    def get(self, todo_id):
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            for r in records:
                if str(todo_id) in r :
                   return r
            return "not found car"

    @api.doc(responses={204: "Todo deleted"})
    def delete(self, todo_id):
        new_records=[]
        if abort_if_todo_exist(todo_id):
           return "mechanic is working cannot delete"
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            x=0
            for r in records:
                if str(todo_id) in r :
                   x=1
                   pass
                else:
                    new_records.append(r)
        if x==0:
           return "no car found"
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return '', 204


    @api.doc(parser=parser)
    @api.marshal_with(todo)
    def put(self, todo_id):
        """Update a given resource"""
        args = parser.parse_args()
        with open('data/cars.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    r[str(todo_id)]['name'] =args['name']
                    r[str(todo_id)]['color'] = args['color']
                    r[str(todo_id)]['cost'] = args['cost']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return "no car found"
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return args, 201
    @api.doc(parser=car_patch)
    @api.marshal_with(todo)
    def patch(self, todo_id):   
        args = car_patch.parse_args()
        with open('data/cars.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    if args['name']:
                        r[str(todo_id)]['name'] =args['name']
                    if args['color']:
                        r[str(todo_id)]['color'] = args['color']
                    if args['cost']:
                        r[str(todo_id)]['cost'] = args['cost']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return "no car found"
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return "success", 204

# TodoList
# shows a list of all todos, and lets you POST 


@ns.route("/")
class TodoList(Resource):
    def get(self):
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            return records

    @api.doc(parser=parser)
    def post(self):
        args = parser.parse_args()
        with open('data/cars.json','r') as f:
            record=args
            data = f.read()
            if not data:
               records = [{0:record}]
            else:
               records = json.loads(data)
               k=records[len(records)-1]
               z=''
               for i in k:
                   z=i
               records.append({int(z)+1:record})
        with open('data/cars.json','w') as f:
             f.write(json.dumps(records, indent=2))
        return record, 201
if __name__ == "__main__":
    app = Flask(__name__)
    app.register_blueprint(api_v1)
    app.run(debug=True)
