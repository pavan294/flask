from flask import Flask, Blueprint
from flask_restx import Api, Resource, fields
import datetime
api_v1 = Blueprint("api", __name__, url_prefix="/mechanics")

api = Api(api_v1, version="1.0", title="Mechanic API", description="A simple mechanic API",)

ns = api.namespace("mechanics", description="Mechanic operations")
import json

todo = api.model('Model', {
    'name': fields.String,
    'car_id': fields.Integer,
    'created_date':fields.DateTime(dt_format='rfc822'),
})
parser = api.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "car_id", type=str, required=True
)
parser.add_argument(
    "created_date",required=True
)
mechanic_patch = api.parser()
mechanic_patch.add_argument(
    "car_id",type=int
    )
mechanic_patch.add_argument(
    "name",type=str
    )
mechanic_patch.add_argument(
    "created_date",type=str
    )
def abort_if_todo_doesnt_exist(todo_id):
    """[check car exists]

    Args:
        todo_id ([type]): [int]
    """
    with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            x=0
            for r in records:
                if str(todo_id) in r :
                   x=1
                   return True
            if x==0:
                return False
@ns.route("/<string:todo_id>")
class Mechanics(Resource):
    """Show a single todo item and lets you delete them"""

    
    def get(self, todo_id):
        with open('data/mechanics.json','r') as f:
            data = f.read()
            records = json.loads(data)
            for r in records:
                if str(todo_id) in r :
                   return r
            return "no mechanic found"

    @api.doc(responses={204: "Todo deleted"})
    def delete(self, todo_id):
        new_records=[]
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            x=0
            for r in records:
                if str(todo_id) in r :
                   x=1
                   pass
                else:
                    new_records.append(r)
        if x==0:
           return "no car found"
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return '', 204


    @api.doc(parser=parser)
    def put(self, todo_id):
        args =parser.parse_args()
        with open('data/mechanics.json', 'r') as f:
            data = f.read()
            if not abort_if_todo_doesnt_exist(args['car_id']):
               return "invalid car_id"
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    r[str(todo_id)]['name'] =args['name']
                    r[str(todo_id)]['car_id'] = args['car_id']
                    r[str(todo_id)]['created_date'] = args['created_date']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return "no mechanic found"
        with open('data/mechanics.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return args, 201
    @api.doc(parser=mechanic_patch)
    def patch(self, todo_id):   
        args =mechanic_patch.parse_args()
        with open('data/mechanics.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    if args['car_id']:
                        if abort_if_todo_doesnt_exist(args['car_id']):
                            r[str(todo_id)]['car_id'] =args['car_id']
                        else:
                            return "invalid car"
                    if args['name']:
                        r[str(todo_id)]['name'] = args['name']
                    if args['created_date']:
                        r[str(todo_id)]['created_date'] = args['created_date']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return "no mechanic found"
        with open('data/mechanics.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return args, 204
@ns.route("/")
class MechanicList(Resource):
    def get(self):
        with open('data/mechanics.json','r') as f:
            data = f.read()
            records = json.loads(data)
            return records

    @api.doc(parser=parser)
    def post(self):
        args = parser.parse_args()
        with open('data/mechanics.json','r') as f:
            record=args
            if not abort_if_todo_doesnt_exist(args['car_id']):
               return "invalid car_id"
            data = f.read()
            if not data:
               records = [{0:record}]
            else:
               records = json.loads(data)
               k=records[len(records)-1]
               z=''
               for i in k:
                   z=i
               records.append({int(z)+1:record})
        with open('data/mechanics.json','w') as f:
            f.write(json.dumps(records, indent=2))
        return record, 201
if __name__ == "__main__":
    app = Flask(__name__)
    app.register_blueprint(api_v1)
    app.run(debug=True)
