from flask import Flask
from flask_restx import Api
from cars import api1 as ns1
from mechanics import api as ns2
app = Flask(__name__)
api = Api(
    app,
    title='Car-Mechanic',
    version='1.0',
    description='car and mechanic resources',
    doc="/api"
    # All API metadatas
)
api.add_namespace(ns1, path='/cars')
api.add_namespace(ns2, path='/mechanics')
if __name__ == "__main__":
    app.run(debug=True)