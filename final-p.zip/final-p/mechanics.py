from flask import Flask
from flask_restx import Resource, fields, Namespace
import json
from json import JSONDecodeError
import io
import datetime
import pytz
from utils import mechanic_op
from utils import car_op
api = Namespace("mechanics", description="Mechanic operations")
mechanicmodel = api.model('Mechanics', {
    'name': fields.String,
    'car_id': fields.Integer,
})
parser = api.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "car_id", type=int, required=True
)

mechanic_patch = api.parser()
mechanic_patch.add_argument(
    "car_id", type=int
    )
mechanic_patch.add_argument(
    "name", type=str
    )
mechanic_filter = api.parser()
mechanic_filter.add_argument(
    'start', type=int, required=True
    )
mechanic_filter.add_argument(
    'limit', type=int, required=True
    )


def abort_if_todo_doesnt_exist(car_id):
    """[check car exists]

    Args:
        todo_id ([type]): [int]
    """
    records = car_op.read()
    if isinstance(records, list):
        item_exists = 0
        for record in records:
            if str(car_id) in record:
                item_exists = 1
                return True
        if item_exists == 0:
            return False


@api.route("/<int:mechanic_id>")
class Mechanics(Resource):
    def get(self, mechanic_id):
        """[get specific mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic objects]
        """
        records = mechanic_op.read()
        if isinstance(records, list):
            for record in records:
                if str(mechanic_id) in record:
                    return record, 200
            return {"error": "no mechanic found"}, 404
        else:
            return {"error": records}, 404

    @api.doc(responses={204: "mechanic deleted"})
    def delete(self, mechanic_id):
        """[delete specified mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [no_content]
        """
        new_records = []
        records = mechanic_op.read()
        new_records = []
        if isinstance(records, list):
            item_exists = 0
            for record in records:
                if str(mechanic_id) in record:
                    item_exists = 1
                    pass
                else:
                    new_records.append(record)
            if item_exists == 0:
                    return {"error": "no mechanic found"}, 404
        else:
            return {"error": record}, 404
        results = mechanic_op.write(new_records)
        if results == "success":
            return ' ', 204
        else:
            return {"error": results}, 404

    @api.doc(parser=parser)
    def put(self, mechanic_id):
        """[update mechanic if car_id is valid]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic object]
        """
        args = parser.parse_args()
        records = mechanic_op.read()
        if isinstance(records, list):
            check = abort_if_todo_doesnt_exist(args['car_id'])
            if not check:
                return {"error": "invalid car_id"}, 404
            elif check != True:
                return check, 404
            new_records = []
            item_exists = 0
            for record in records:
                if str(mechanic_id) in record:
                    item_exists = 1
                    record[str(mechanic_id)]['name'] = args['name']
                    record[str(mechanic_id)]['car_id'] = str(args['car_id'])
                    timezone = pytz.timezone('Europe/Berlin')
                    date = datetime.datetime.now(timezone)
                    record[str(mechanic_id)]['created_at'] = date.isoformat()
                    new_records.append(record)
                else:
                    new_records.append(record)
            if item_exists == 0:
                    return {"error": "no mechanic found"},  404
        else:
            return {"error": records}, 404
        results = mechanic_op.write(new_records)
        if results == "success":
            return args, 200
        else:
            return {"errors": results}, 400

    @api.expect(mechanicmodel)
    @api.marshal_with(mechanicmodel, skip_none=True)
    def patch(self, mechanic_id):
        """[partially update mechanic if car_id is valid]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic object]
        """
        args = mechanic_patch.parse_args()
        records = mechanic_op.read()
        new_records = []
        if isinstance(records, list):
            item_exists = 0
            for record in records:
                if str(mechanic_id) in record:
                    item_exists = 1
                    if args['car_id'] != None:
                        if abort_if_todo_doesnt_exist(args['car_id']):
                            record[str(mechanic_id)]['car_id'] = str(args['car_id'])
                            timezone = pytz.timezone('Europe/Berlin')
                            date = datetime.datetime.now(timezone)
                            record[str(mechanic_id)]['created_at'] = date.isoformat()
                        else:
                            return "invalid car", 409
                    if args['name']:
                        record[str(mechanic_id)]['name'] = args['name']
                        timezone = pytz.timezone('Europe/Berlin')
                        date = datetime.datetime.now(timezone)
                        record[str(mechanic_id)]['created_at'] = date.isoformat()
                    new_records.append(record)
                else:
                    new_records.append(record)
            if not item_exists:
                return {"error": "no mechanic found"}, 404
        else:
            return {"error": records}, 404
        results = mechanic_op.write(new_records)
        if results == "success":
            return args, 200
        else:
            return {"error": results}, 404
        

@api.route("/")
class MechanicList(Resource):
    @api.doc(parser=parser)
    def post(self):
        """adds an mechanic

        Returns:
            [type]: [mechanic object]
        """
        args = parser.parse_args()
        records = mechanic_op.read()
        if isinstance(records, list):
            args['car_id'] = str(args['car_id'])
            timezone = pytz.timezone('Europe/Berlin')
            k = {"created_at": datetime.datetime.now(timezone).isoformat()}
            args.update(k)
            if not abort_if_todo_doesnt_exist(args['car_id']):
                return {"error": "invalid car_id"}, 404
            last_item = records[len(records)-1]
            index = ''
            for key in last_item:
                index = key
                records.append({str(int(index)+1): args})
        else:
            return {"error": records}
        result = mechanic_op.write(records)
        if result == "success":
            return args, 201
        else:
            return {"error": result}, 404


@api.route("/MechanicsList")
class PaginateList(Resource):
    @api.doc(parser=mechanic_filter)
    def get(self):
        """pagination for mechaniclists

        Returns:
            [type]: [mechanic objects]
        """
        args = mechanic_filter.parse_args()
        url = "http://127.0.0.1:5000/mechanicspaginate"
        results = mechanic_op.read()
        if isinstance(results, list):
            start = args['start'] 
            limit = args['limit']
            count = len(results)
            if (count < start):
                return {"error": "pagination not possible"}, 404
            obj = {}
            obj['start'] = start
            obj['limit'] = limit
            obj['count'] = count
            if start == 1:
                obj['previous'] = ''
            else:
                start_copy = max(1, start - limit)
                limit_copy = start - 1
                obj['previous'] = url + '?start=%d&limit=%d' % (
                                  start_copy, limit_copy)
            if start + limit == count+1:
                obj['next'] = ''
                obj['results'] = results[(start - 1):(start - 1 + limit)]
            elif start + limit > count+1:
                obj['next'] = ''
            else:
                start_copy = start + limit
                obj['next'] = url + '?start=%d&limit=%d' % (start_copy, limit)
                obj['results'] = results[(start - 1):(start - 1 + limit)]
            return obj, 200
        else:
            return {"error": results}, 404


@api.route("/mechanicsfilter")
class MechanicMultiple(Resource):
    @api.doc(parser=mechanic_patch)
    def get(self):
        """filter multiple elements"""
        args = mechanic_patch.parse_args()
        records = mechanic_op.read()
        if isinstance(records, list):
            new_records = []
            for record in records:
                for key, value in record.items():
                    if((args['name'] == None or
                        args['name'] == value['name']) and
                        (args['car_id'] == None or
                        str(args['car_id']) == value['car_id'])): 
                        new_records.append(record)
                    else:
                        pass
            if new_records == []:
                return {"error": "no mechanic found"}, 404
            return new_records, 200
        else:
            return {"errors": records}, 404


def get_cars(car_id):
    records = car_op.read()
    if isinstance(records, list):
        for record in records:
                if str(car_id) in record:
                    return record
        return {"error": "no car found"}
    else:
        return {"error": "records"}


@api.route("/cars/<int:mechanic_id>")
class WorkerCars(Resource):
    def get(self, mechanic_id):
        """[get cars of mechanic]

        Args:
            mechanic_id ([type]): [int]

        Returns:
            [type]: [mechanic objects]
        """
        records = mechanic_op.read()
        if isinstance(records, list):
            for record in records:
                    if str(mechanic_id) in record:
                        return get_cars(record[str(mechanic_id)]['car_id']), 200
            return {"error": "no mechanic found"}, 404
        else:
            return {"errors": records}, 200

if __name__ == "__main__":
    app = Flask(__name__)
    app.run(debug=True)
