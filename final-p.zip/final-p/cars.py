from flask import Flask
from flask_restx import Resource, fields, Namespace
from json import JSONDecodeError
import json
import io
from utils import car_op
from utils import mechanic_op
api1 = Namespace("cars", description="car operations")
carmodel = api1.model('Cars', {
    'name': fields.String,
    'color': fields.String,
    'cost': fields.Integer,
})
parser = api1.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "color", type=str, required=True
)
parser.add_argument(
    "cost", type=int, required=True
)

car_patch = api1.parser()
car_patch.add_argument(
    'color', type=str
    )
car_patch.add_argument(
    'name', type=str
    )
car_patch.add_argument(
    'cost', type=int
    )
car_filter = api1.parser()
car_filter.add_argument(
    'start', type=int, required=True
    )
car_filter.add_argument(
    'limit', type=int, required=True
    )


def abort_if_todo_exist(car_id):
    """[check whether mechanic is assigned]

    Args:
        todo_id ([type]): [int]
    """
    records = mechanic_op.read()
    if isinstance(records, list):
        for record in records:
                for key, value in record.items():
                    if value['car_id'] == car_id:
                        return True
        return False


@api1.route("/mechanics/<int:car_id>")
class Workers(Resource):
    def get(self, car_id):
        """get mechanics for specified car

        Args:
            todo_id ([type]): [car_id]

        Returns:
            [type]: [mechanics list]
        """
        records = mechanic_op.read()
        if isinstance(records, list):
            new_records = []
            for record in records:
                for key, value in record.items():
                    if value['car_id'] == str(car_id):
                        new_records.append(record)
            if new_records == []:
                return {"error": "no mechanic found"}, 404
            return new_records, 200
        else:
            return {"error": records}, 404


@api1.route("/<int:car_id>")
class Todo(Resource):
    def get(self, car_id):
        """get specified car

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [mechanic object]
        """
        records = car_op.read()
        if isinstance(records, list):
                for record in records:
                    if str(car_id) in record:
                        return record, 200
                return {"error": "car not found"}, 404
        else:
            return {"error": records}, 404

    def delete(self, car_id):
        """delete car if mechanic is not working

        Args:
            todo_id ([type]): [int]

        Returns:
            [no-content]
        """
        new_records = []
        check = abort_if_todo_exist(str(car_id))
        if check:
            return {"error": "mechanic is working cannot delete"}, 409
        elif check != False:
            return {"errors": check}, 404      
        records = car_op.read()
        if isinstance(records, list):
            item_exists = 0
            for record in records:
                if str(car_id) in record:
                    item_exists = 1
                    pass
                else:
                    new_records.append(record)
            if item_exists == 0:
                return {"error": "no car found"}, 404
        else:
            return {"error": records}, 404
        results = car_op.write(new_records)
        if results == "success":
            return " ", 204
        else:
            return {"error": results}, 404

    @api1.expect(parser, validate=True)
    def put(self, car_id):
        """Update a given resource"""
        args = parser.parse_args()
        records = car_op.read()
        if isinstance(records, list):
                new_records = []
                item_exists = 0
                for record in records:
                    if str(car_id) in record:
                        item_exists = 1
                        record[str(car_id)]['name'] = args['name']
                        record[str(car_id)]['color'] = args['color']
                        record[str(car_id)]['cost'] = args['cost']
                        new_records.append(record)
                    else:
                        new_records.append(record)
                if item_exists == 0:
                    return {"error": "no car found"}, 404
        else:
            return {"error": records}, 404
        result = car_op.write(new_records)
        if result == "success":
            return args, 200
        else:
            return {"error": result}, 404

    @api1.expect(carmodel)
    @api1.marshal_with(carmodel, skip_none=True)
    def patch(self, car_id):
        """partially update given resource"""
        args = car_patch.parse_args()
        records = car_op.read()
        if isinstance(records, list):
            new_records = []
            item_exists = 0
            for record in records:
                if str(car_id) in record:
                    item_exists = 1
                    if args['name']:
                        record[str(car_id)]['name'] = args['name']
                    if args['color']:
                        record[str(car_id)]['color'] = args['color']
                    if args['cost'] != None:
                        record[str(car_id)]['cost'] = args['cost']
                    new_records.append(record)
                else:
                    new_records.append(record)
            if item_exists == 0:
                    return {"error": "no car found"}, 404
        else:
            return {"error": records}, 404
        result = car_op.write(new_records)
        if result == "success":
            return args, 200
        else:
            return {"error": result}, 404


@api1.route("/")
class TodoList(Resource):
    @api1.doc(parser=parser)
    def post(self):
        """create a car

        Returns:
            [type]: [car object]
        """
        record = parser.parse_args()
        new_records = car_op.read()
        if isinstance(new_records, list):
            last_item = new_records[len(new_records)-1]
            index = ''
            for items in last_item:
                index = items
                new_records.append({int(index)+1: record})
        else:
            new_records = [{0: record}]
        result = car_op.write(new_records)
        if result == "success":
            return record, 201
        else:
            return {"errors": result}, 404
    

@api1.route("/CarsList")
class PaginateList(Resource):
    @api1.doc(parser=car_filter)
    def get(self):
        """pagination for carlists

        Returns:
            [type]: [car objects]
        """
        args = car_filter.parse_args()
        url = "http://127.0.0.1:5000/carspaginate"
        results = car_op.read()
        if isinstance(results, list):
            start = args['start'] 
            limit = args['limit']
            count = len(results)
            if (count < start):
                return {"error": "pagination not possible"}, 404
            obj = {}
            obj['start'] = start
            obj['limit'] = limit
            obj['count'] = count
            if start == 1:
                obj['previous'] = ''
            else:
                start_copy = max(1, start - limit)
                limit_copy = start - 1
                obj['previous'] = url + '?start=%d&limit=%d' % (
                                  start_copy, limit_copy)
            if start + limit == count+1:
                obj['next'] = ''
                obj['results'] = results[(start - 1):(start - 1 + limit)]
            elif start + limit > count+1:
                obj['next'] = ''
            else:
                start_copy = start + limit
                obj['next'] = url + '?start=%d&limit=%d' % (start_copy, limit)
                obj['results'] = results[(start - 1):(start - 1 + limit)]
            return obj, 200
        else:
            return {"error": results}, 404

    
@api1.route("/carsfilter")
class CarMultiple(Resource):
    @api1.doc(parser=car_patch)
    def get(self):
        """filter multiple elements"""
        args = car_patch.parse_args()
        records = car_op.read()
        if isinstance(records, list):
                new_records = []
                for record in records:
                    for key, value in record.items():
                        if((args['name'] == None or
                            args['name'] == value['name']) and
                            (args['color'] == None or
                             args['color'] == value['color']) and
                            (args['cost'] == None or
                             args['cost'] == value['cost'])):
                            new_records.append(record)
                        else:
                            pass
                if new_records == []:
                    return {"error": "no car found"}, 404
                return new_records, 200
        else:
            return  {"error":records}, 404
        
if __name__ == "__main__":
    app = Flask(__name__)
    app.run(debug=True)
