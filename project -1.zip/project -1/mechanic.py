from flask import Flask,jsonify
from flask_restful import reqparse, abort, Api, Resource
import json
app = Flask(__name__)
api = Api(app)
parser= reqparse.RequestParser()
mechanic_put = reqparse.RequestParser()
mechanic_put.add_argument('car_id',type=str,required=True)
mechanic_put.add_argument('name',type=str,required=True)
mechanic_put.add_argument('created_at',required=True)
mechanic_patch = reqparse.RequestParser()
mechanic_patch.add_argument('car_id',type=str)
mechanic_patch.add_argument('name',type=str)
mechanic_patch.add_argument('created_at')
def abort_if_todo_doesnt_exist(todo_id):
    """[check car exists]

    Args:
        todo_id ([type]): [int]
    """
    with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            print(records)
            x=0
            for r in records:
                if str(todo_id) in r :
                   x=1
                   break
            if x==0:
                abort(404, message=f"car {todo_id} doesn't exist")
class Mechanic(Resource):
    def get(self, todo_id):
        """[specific mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [json object]
        """
        with open('data/mechanic.json','r') as f:
            data = f.read()
            records = json.loads(data)
            for r in records:
                if str(todo_id) in r :
                   return r
            return jsonify("no mechanic found")

    def delete(self, todo_id):
        """[delete an existing mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [Null]
        """
        new_records=[]
        with open('data/mechanic.json','r') as f:
            data = f.read()
            records = json.loads(data)
            x=0
            for r in records:
                if str(todo_id) in r :
                   x=1
                   pass
                else:
                    new_records.append(r)
        if x==0:
           return jsonify("mechanic not found")
        with open('data/mechanic.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return '', 204

    def put(self, todo_id):
        """[update all items in mechanic]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [json object]
        """
        args = mechanic_put.parse_args()
        with open('data/mechanic.json', 'r') as f:
            data = f.read()
            abort_if_todo_doesnt_exist(args['car_id'])
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    r[str(todo_id)]['name'] =args['name']
                    r[str(todo_id)]['car_id'] = args['car_id']
                    r[str(todo_id)]['created_at'] = args['created_at']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return jsonify("no mechanic found")
        with open('data/mechanic.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return args, 201
    def patch(self,todo_id):
        args = mechanic_patch.parse_args()
        with open('data/mechanic.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    if args['car_id']:
                        abort_if_todo_doesnt_exist(args['car_id'])
                        r[str(todo_id)]['car_id'] =args['car_id']
                    if args['name']:
                        r[str(todo_id)]['name'] = args['name']
                    if args['created_at']:
                        r[str(todo_id)]['created_at'] = args['created_at']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return jsonify("no mechanic found")
        with open('data/mechanic.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return args, 204

# TodoList
# shows a list of all todos, and lets you POST to add new tasks
class MechanicList(Resource):
    def get(self):
        """[get all mechanics]

        Returns:
            [type]: [json objects list]
        """
        with open('data/mechanic.json','r') as f:
            data = f.read()
            records = json.loads(data)
            return records

    def post(self):
        """[create new items]

        Returns:
            [type]: [json object]
        """
        args = mechanic_put.parse_args()
        #todo_id = int(max(TODOS.keys()).lstrip('todo')) + 1
        #todo_id = 'todo%i' % todo_id
        with open('data/mechanic.json','r') as f:
            record=args
            abort_if_todo_doesnt_exist(args['car_id'])
            data = f.read()
            if not data:
               records = [{0:record}]
            else:
               records = json.loads(data)
               k=records[len(records)-1]
               z=''
               for i in k:
                   z=i
               records.append({int(z)+1:record})
        with open('data/mechanic.json','w') as f:
            f.write(json.dumps(records, indent=2))
        return record, 201

##
## Actually setup the Api resource routing here
##
api.add_resource(MechanicList, '/mechanic')
api.add_resource(Mechanic, '/mechanic/<todo_id>')


if __name__ == '__main__':
    app.run(debug=True)
