def fun(a,b):
    print("Hello")
    