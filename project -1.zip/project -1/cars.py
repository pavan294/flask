from flask import Flask,jsonify
from flask_restful import reqparse, abort, Api, Resource
import json
app = Flask(__name__)
api = Api(app)
parser= reqparse.RequestParser()
car_put = reqparse.RequestParser()
car_put.add_argument('color',type=str,required=True)
car_put.add_argument('name',type=str,required=True)
car_put.add_argument('cost',type=int,required=True)
car_patch = reqparse.RequestParser()
car_patch.add_argument('color',type=str)
car_patch.add_argument('name',type=str)
car_patch.add_argument('cost',type=int)
car_filter = reqparse.RequestParser()
car_filter.add_argument('cost',type=int)
def abort_if_todo_exist(todo_id):
    """[check whether mechanic is assigned]

    Args:
        todo_id ([type]): [int]
    """
    with open('data/mechanic.json','r') as f:
            data = f.read()
            records = json.loads(data)
            for r in records:
                for k,v in r.items():
                    if v['car_id'] ==todo_id:
                        abort(404, message=f"does not perform as mechanic{k} working")
# Todo
# shows a single todo item and lets you delete a todo item
class CarFilter(Resource):
      def get(self,todo_id):
          """[get all mechanics working on a specific car]

          Args:
              todo_id ([type]): [int]

          Returns:
              [type]: [json list of mechanics]
          """
          with open('data/mechanic.json','r') as f:
            data = f.read()
            records = json.loads(data)
            l=[]
            for r in records:
                for k,v in r.items():
                    if v['car_id'] ==todo_id:
                       l.append(r)
            return jsonify(l)
class Car(Resource):
    def get(self, todo_id):
        """[get specific car]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [json objects]
        """
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            for r in records:
                if str(todo_id) in r :
                   return r
            return jsonify("not found")

    def delete(self, todo_id):
        """[delete a specific car if mechanic not assigned"]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [json objects]
        """
        new_records=[]
        abort_if_todo_exist(todo_id)
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            x=0
            for r in records:
                if str(todo_id) in r :
                   x=1
                   pass
                else:
                    new_records.append(r)
        if x==0:
           return jsonify("no car found")
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return '', 204

    def put(self, todo_id):
        """[update all elements]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [json objects]
        """
        args = car_put.parse_args()
        with open('data/cars.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    r[str(todo_id)]['name'] =args['name']
                    r[str(todo_id)]['color'] = args['color']
                    r[str(todo_id)]['cost'] = args['cost']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return jsonify("no car found")
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return args, 201
    def patch(self,todo_id):
        """[partial update of car elements]

        Args:
            todo_id ([type]): [int]

        Returns:
            [type]: [string]
        """
        args = car_patch.parse_args()
        with open('data/cars.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            x=0
            for r in records:
                if str(todo_id) in r :
                    x=1
                    if args['name']:
                        r[str(todo_id)]['name'] =args['name']
                    if args['color']:
                        r[str(todo_id)]['color'] = args['color']
                    if args['cost']:
                        r[str(todo_id)]['cost'] = args['cost']
                    new_records.append(r)
                else:
                    new_records.append(r)
        if x==0:
           return jsonify("no car found")
        with open('data/cars.json', 'w') as f:
            f.write(json.dumps(new_records, indent=2))
        return "success", 204

# TodoList
# shows a list of all todos, and lets you POST to add new tasks
class CarsList(Resource):
    def get(self):
        """[get all list of cars]

        Returns:
            [type]: [list of json objects]
        """
        with open('data/cars.json','r') as f:
            data = f.read()
            records = json.loads(data)
            return records

    def post(self):
        """[create cars]

        Returns:
            [type]: [json object]
        """
        args = car_put.parse_args()
        #todo_id = int(max(TODOS.keys()).lstrip('todo')) + 1
        #todo_id = 'todo%i' % todo_id
        with open('data/cars.json','r') as f:
            record=args
            data = f.read()
            if not data:
               records = [{0:record}]
            else:
               records = json.loads(data)
               k=records[len(records)-1]
               z=''
               for i in k:
                   z=i
               records.append({int(z)+1:record})
        with open('data/cars.json','w') as f:
            f.write(json.dumps(records, indent=2))
        return record, 201

##
## Actually setup the Api resource routing here
##
api.add_resource(CarsList, '/cars')
api.add_resource(Car, '/cars/<todo_id>')
api.add_resource(CarFilter, '/carsfilter/<todo_id>')
if __name__ == '__main__':
    app.run(debug=True)
