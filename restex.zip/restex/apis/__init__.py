from flask_restx import Api
from apis.cars import api as ns1
from apis.mechanics import api as ns2

api = Api(
    title='Main app',
    version='1.0',
    description='car-mechanic',
    # All API metadatas
)

api.add_namespace(ns1)
api.add_namespace(ns2)