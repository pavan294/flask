from flask import Flask, Blueprint
from flask_restx import Api, Resource, fields
api_v1 = Blueprint("api", __name__, url_prefix="/lists")
api = Api(api_v1, version="1.0", title="car API", description="A simple car API",)
ns = api.namespace("cars", description="car operations")
import json
todo = api.model('Model', {
    'name': fields.String,
    'color': fields.String,
    'cost': fields.Integer,
})
car_patch = api.parser()
car_patch.add_argument(
    'color',type=str
    )
car_patch.add_argument(
    'name',type=str
    )
car_patch.add_argument(
    'cost',type=int
    )
@ns.route("/cars")
class Todo(Resource):
    @api.doc(parser=car_patch)
    def patch(self):  
        args = car_patch.parse_args()
        with open('data/cars.json', 'r') as f:
            data = f.read()
            records = json.loads(data)
            new_records=[]
            for r in records:
                for k,v in r.items():
                    if args['name']:
                        if args['name']==v['name']:
                            new_records.append(r) 
            print(new_records)
            return new_records
                       
        
if __name__ == "__main__":
    app = Flask(__name__)
    app.register_blueprint(api_v1)
    app.run(debug=True)      
        
    

      
