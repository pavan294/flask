from flask import Flask,render_template,redirect,request,flash
from flask_bootstrap import Bootstrap
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from flask_sqlalchemy import SQLAlchemy
from wtforms_alchemy import ModelForm
app = Flask(__name__)
app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] =False
db= SQLAlchemy(app)
app.config['SECRET_KEY'] = 'C2HWGVoMGfNTBsrYQg8EcMrdTimkZfAb'
# Flask-Bootstrap requires this line
Bootstrap(app)
class pser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username
class NameForm(FlaskForm):
    name = StringField('Which actor is your favorite?')
    submit = SubmitField('Submit')

class pserForm(ModelForm):
    class Meta:
        model =pser
@app.route('/',methods=['POST','GET'])
def index():
    if request.method=="POST":
        task=request.form['content']
        email=request.form['email']
        a=pser(username=task,email=email)
        try:
           db.session.add(a)
           db.session.commit()
           return redirect("/")
        except:
            return "issue"
    else:
        db.create_all()
        task= pser.query.all()
        return render_template("index.html",tasks=task)
@app.route('/1',methods=['POST','GET'])
def index1():
    if request.method=="POST":
        a=pser(username=request.form['username'],email=request.form['email'])
        try:
           db.session.add(a)
           db.session.commit()
           return redirect("/1")
        except:
            return "issue"
    else:
        db.create_all()
        form=pserForm()
        task= pser.query.all()
        return render_template("index1.html",form=form,tasks=task)
@app.route('/updateform/<int:id>')
def updateform(id):
    a=pser.query.get_or_404(id)
    form=pserForm(obj=a)
    return render_template("updateform.html",form=form,id=id)
@app.route('/pavan/',methods=['POST','GET'])  
def get_id():
    form=NameForm()
    return render_template('pavan.html',form=form)
@app.route('/devika/',methods=['POST','GET'])
def get_print():
    return request.form['name']
@app.route('/delete/<int:id>')
def delete(id):
    try:
        a=pser.query.get_or_404(id)
        db.session.delete(a)
        db.session.commit()
        return redirect('/')
    except:
        return "error"
@app.route('/search/',methods=['POST','GET'])
def search():
    if request.method=="POST":
        a=pser.query.filter_by(id=int(request.form['id']))
        return render_template("index.html",tasks=a)
        
@app.route('/update1/<int:id>',methods=['POST','GET'])
def update1(id):
        a=pser.query.get_or_404(id) 
        form=pserForm(request.form,obj=a)
        if request.method == 'POST' and form.validate:
            a.username=request.form['username']
            a.email=request.form['email']
            try:
                db.session.commit()
                return redirect("/1")
            except:
                flash('No update')
                return render_template('result.html')
@app.route('/update/<int:id>',methods=['POST','GET'])
def update(id):
        if request.method=="POST":
            a=pser.query.get_or_404(id) 
            a.username=request.form['content']
            a.email=request.form['email']
            try:
                db.session.commit()
                return redirect("/")
            except:

                return "issue"
'''
@app.route('/user/<name>')
def user(name):
 return '<h1>Hello, %s!</h1>' % name
'''
if __name__ == '__main__':
 app.run(debug=True)