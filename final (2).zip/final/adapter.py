import json
from bson import json_util,ObjectId
from pymongo import MongoClient
class Adapter:
    def __init__(self):
        self.client=MongoClient("mongodb://localhost:27017")
        self.db=self.client.cardb
        self.collection=self.db.cardb
    def get_items(self):
        return json.loads(json_util.dumps(self.collection.find()))
    def post_item(self,record):
        self.collection.insert_one(record)
    def delete_item(self,id):
        self.collection.delete_one({"_id":ObjectId(id)})
    def put_item(self,id,body):
        self.collection.update_one({"_id":ObjectId(id)},{"$set":body})