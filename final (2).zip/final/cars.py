from flask import Flask,jsonify
from flask_restx import Resource, fields, Namespace
from adapter import Adapter
import json
import datetime
import pytz
from utils import mechanic_op
api1 = Namespace("cars", description="car operations")
carmodel = api1.model('Cars', {
    'name': fields.String,
    'color': fields.String,
    'cost': fields.Integer,
})
parser = api1.parser()
parser.add_argument(
    "name", type=str, required=True
)
parser.add_argument(
    "color", type=str, required=True
)
parser.add_argument(
    "cost", type=int, required=True
)
car_put = api1.parser()
car_put.add_argument(
    "name", type=str, required=True
)
car_put.add_argument(
    "color", type=str, required=True
)
car_put.add_argument(
    "cost", type=int, required=True
)
car_patch = api1.parser()
car_patch.add_argument(
    'color', type=str
    )
car_patch.add_argument(
    'name', type=str
    )
car_patch.add_argument(
    'cost', type=int
    )
obj=Adapter()
@api1.route("/<string:car_id>")
class Todo(Resource):

    def delete(self, car_id):
        obj.delete_item(car_id)
        return {"success":''},204

    @api1.expect(car_put, validate=True)
    def put(self, car_id):
        args =car_put.parse_args()
        body={"name":args['name'],"color":args['color'],"cost":args['cost']}
        obj.put_item(car_id,body)
        return {"put success":args},200

    @api1.expect(carmodel)
    @api1.marshal_with(carmodel, skip_none=True)
    def patch(self,car_id):
        args=car_patch.parse_args()
        if args['name'] != None:
            obj.put_item(car_id,{"name":args['name']})
        if args['color'] != None:
            obj.put_item(car_id,{"color":args['color']})
        if args['cost'] != None:
            obj.put_item(car_id,{"cost":args['cost']})          
        return {"patch success":args},200

@api1.route("/")
class TodoList(Resource):
    @api1.doc(parser=parser)
    def post(self):
        record = parser.parse_args()
        timezone = pytz.timezone('Europe/Berlin')
        date = {"created_at": datetime.datetime.now(timezone).isoformat()}
        record.update(date)
        obj.post_item(record)
        return {"success":"post"},201
@api1.route("/CarsList")
class PaginateList(Resource):
    def get(self):
        results = obj.get_items()
        return results,200 
if __name__ == "__main__":
    app = Flask(__name__)
    app.run(debug=True)
